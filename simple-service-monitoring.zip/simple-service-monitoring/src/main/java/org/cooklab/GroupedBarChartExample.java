package org.cooklab;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryMarker;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class GroupedBarChartExample extends ApplicationFrame {

    public GroupedBarChartExample(String title) {
        super(title);
        DefaultCategoryDataset dataset = createDataset();
        JFreeChart chart = createChart(dataset);
        ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new java.awt.Dimension(800, 600));
        setContentPane(chartPanel);
    }
a
    private DefaultCategoryDataset createDataset() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        String[] services = {"Rest1", "Rest2", "Rest3","Rest4", "Rest5", "Rest6", "Rest7", "Rest8", "Rest9"};
        String[] categories = {"Min", "Max", "Median"};
        String[] servers = {"S1", "S2", "S3", "S4", "S5", "S6", "S7", "S8", "S9"};

        // Add data for each service and response time category (Minimum, Maximum, Median)
        for (String service : services) {
            for (String server : servers) {
                // Replace these values with your actual data
                double minResponseTime = Math.random() * 100;
                double maxResponseTime = Math.random() * 100;
                double medianResponseTime = Math.random() * 100;

                dataset.addValue(minResponseTime, service, server + " - Min");
                dataset.addValue(maxResponseTime, service, server + " - Max");
                dataset.addValue(medianResponseTime, service, server + " - Median");
            }
        }

        return dataset;
    }

    private JFreeChart createChart(DefaultCategoryDataset dataset) {
        JFreeChart chart = ChartFactory.createBarChart(
                "Service Performance Statistics",
                "Services",
                "Response Time (ms)",
                dataset,
                PlotOrientation.VERTICAL,
                true, true, false
        );

        return chart;
    }

    public static void main(String[] args) {
        GroupedBarChartExample chart = new GroupedBarChartExample("Service Performance Statistics");
        chart.pack();
        RefineryUtilities.centerFrameOnScreen(chart);
        chart.setVisible(true);
    }
}


