package org.cooklab;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

import javax.activation.DataSource;
import javax.imageio.ImageIO;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;
import javax.mail.util.ByteArrayDataSource;
import javax.activation.DataHandler;


public class ServicePerformanceTest {
    public static void main(String[] args) throws IOException, MessagingException {
        String apiUrl = "https://jsonplaceholder.typicode.com/posts/1"; // Replace with your API endpoint
        int numberOfRequests = 5;

        List<Long> responseTimes = new ArrayList<>();

        for (int i = 0; i < numberOfRequests; i++) {
            long startTime = System.currentTimeMillis();

            URL url = new URL(apiUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");

            int responseCode = connection.getResponseCode();
            long endTime = System.currentTimeMillis();

            long responseTime = endTime - startTime;
            responseTimes.add(responseTime);

            System.out.println("Request " + (i + 1) + " - Response Code: " + responseCode + ", Response Time (ms): " + responseTime);
        }

        Collections.sort(responseTimes);

        long minResponseTime = responseTimes.get(0);
        long maxResponseTime = responseTimes.get(responseTimes.size() - 1);
        long medianResponseTime = responseTimes.get(responseTimes.size() / 2);

        // Create a bar chart and save it as an image
        JFreeChart chart = createBarChart(minResponseTime, maxResponseTime, medianResponseTime);
        byte[] chartImageBytes = saveChartAsImage(chart);

        //sendEmail(minResponseTime, maxResponseTime, medianResponseTime, chartImageBytes);
        System.out.println("min"+minResponseTime+ " ~ "+"max"+maxResponseTime+ " ~ "+"median"+medianResponseTime);
        String filePath = "output.png"; // Path to the output file

        try (FileOutputStream fos = new FileOutputStream(filePath)) {
            fos.write(chartImageBytes);
            System.out.println("Data written to file successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private static JFreeChart createBarChart(long minResponseTime, long maxResponseTime, long medianResponseTime) {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(minResponseTime, "service1", "Minimum Response Time");
        dataset.addValue(maxResponseTime, "service1", "Maximum Response Time");
        dataset.addValue(medianResponseTime, "service1", "Median Response Time");

        dataset.addValue(minResponseTime, "service2", "Minimum Response Time");
        dataset.addValue(maxResponseTime, "service2", "Maximum Response Time");
        dataset.addValue(medianResponseTime, "service2", "Median Response Time");

        JFreeChart barChart = ChartFactory.createBarChart("REST Service Performance Report", "Statistics", "Response Time (ms)", dataset, PlotOrientation.VERTICAL, true, true, false);

        return barChart;
    }

    private static byte[] saveChartAsImage(JFreeChart chart) throws IOException {
        BufferedImage image = chart.createBufferedImage(800, 400);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        ImageIO.write(image, "png", byteArrayOutputStream);
        return byteArrayOutputStream.toByteArray();
    }

    private static void sendEmail(long minResponseTime, long maxResponseTime, long medianResponseTime, byte[] chartImageBytes) throws MessagingException {
        // Configure your email settings and credentials
        String host = "your_smtp_host";
        String port = "your_smtp_port";
        String username = "your_email_username";
        String password = "your_email_password";
        String fromAddress = "your_email_address";
        String toAddress = "recipient_email_address";

        Properties properties = new Properties();
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");
        properties.put("mail.smtp.host", host);
        properties.put("mail.smtp.port", port);

        Session session = Session.getInstance(properties, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        });

        MimeMessage message = new MimeMessage(session);
        message.setFrom(new InternetAddress(fromAddress));
        message.setRecipient(Message.RecipientType.TO, new InternetAddress(toAddress));
        message.setSubject("REST Service Performance Report");

        // Create a tabular format for the email body
        String emailBody = "<html><body><table border='1'><tr><th>Statistic</th><th>Value (ms)</th></tr>"
                + "<tr><td>Minimum Response Time</td><td>" + minResponseTime + "</td></tr>"
                + "<tr><td>Maximum Response Time</td><td>" + maxResponseTime + "</td></tr>"
                + "<tr><td>Median Response Time</td><td>" + medianResponseTime + "</td></tr>"
                + "</table></body></html>";

        message.setContent(emailBody, "text/html");

        // Attach the chart as an image
        DataSource dataSource = new ByteArrayDataSource(chartImageBytes, "image/png");
        message.setDataHandler(new DataHandler(dataSource));
        message.setFileName("performance_chart.png");

        Transport.send(message);

        System.out.println("Email sent successfully!");
    }
}
