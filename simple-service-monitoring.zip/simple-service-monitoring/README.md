Simple-Service-Monitoring

This is a java project for monitoring your rest services and sending out a notification of the response times.
