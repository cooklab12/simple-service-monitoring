package org.cooklab;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.activation.DataSource;
import javax.mail.util.ByteArrayDataSource;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtils;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;
import java.util.Arrays;
import javax.mail.util.ByteArrayDataSource;
import javax.activation.DataHandler;

public class MultiServicePerformanceTest {
    public static void main(String[] args) {
        List<ServiceInfo> services = Arrays.asList(
                new ServiceInfo("Service 1", "https://service1/api"),
                new ServiceInfo("Service 2", "https://service2/api")
                // Add more services as needed
        );

        for (ServiceInfo service : services) {
            PerformanceData data = measureServicePerformance(service);
            JFreeChart chart = createChart(data);
            String tabularData = createTabularData(data);
            String emailBody = composeEmailBody(tabularData, chart);
            //sendEmail(service.getName(), emailBody);
        }
    }

    private static PerformanceData measureServicePerformance(ServiceInfo service) {
        int numberOfRequests = 5;
        List<Long> responseTimes = new ArrayList<>();

        for (int i = 0; i < numberOfRequests; i++) {
            long startTime = System.currentTimeMillis();

            try {
                URL url = new URL(service.getEndpoint());
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");

                int responseCode = connection.getResponseCode();
                long endTime = System.currentTimeMillis();

                long responseTime = endTime - startTime;
                responseTimes.add(responseTime);

                System.out.println(service.getName() + " - Request " + (i + 1) + " - Response Code: " + responseCode + ", Response Time (ms): " + responseTime);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        Collections.sort(responseTimes);

        long minResponseTime = responseTimes.get(0);
        long maxResponseTime = responseTimes.get(responseTimes.size() - 1);
        long medianResponseTime = responseTimes.get(responseTimes.size() / 2);

        return new PerformanceData(minResponseTime, maxResponseTime, medianResponseTime);
    }

    private static JFreeChart createChart(PerformanceData data) {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(data.getMinResponseTime(), "Statistics", "Minimum Response Time");
        dataset.addValue(data.getMaxResponseTime(), "Statistics", "Maximum Response Time");
        dataset.addValue(data.getMedianResponseTime(), "Statistics", "Median Response Time");

        return ChartFactory.createBarChart("Service Performance Report", "Statistics", "Response Time (ms)", dataset, PlotOrientation.VERTICAL, true, true, false);
    }

    private static String createTabularData(PerformanceData data) {
        return "<html><body><table border='1'><tr><th>Statistic</th><th>Value (ms)</th></tr>" +
                "<tr><td>Minimum Response Time</td><td>" + data.getMinResponseTime() + "</td></tr>" +
                "<tr><td>Maximum Response Time</td><td>" + data.getMaxResponseTime() + "</td></tr>" +
                "<tr><td>Median Response Time</td><td>" + data.getMedianResponseTime() + "</td></tr>" +
                "</table></body></html>";
    }

    private static String composeEmailBody(String tabularData, JFreeChart chart) {
        BufferedImage image = chart.createBufferedImage(800, 400);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

        /*try {
            ImageIO.write(image, "png", byteArrayOutputStream);
        } catch (IOException e) {
            e.printStackTrace();
        }*/

        DataSource dataSource = new ByteArrayDataSource(byteArrayOutputStream.toByteArray(), "image/png");
        String chartAttachment = "<img src='cid:chart'><br><br>";

        return "<html><body>" + chartAttachment + tabularData + "</body></html>";
    }

    private static void sendEmail(String serviceName, String emailBody) {
        // Configure your email settings and recipients
        String host = "your_smtp_host";
        String port = "your_smtp_port";
        String username = "your_email_username";
        String password = "your_email_password";
        String fromAddress = "your_email_address";
        String toAddress = "recipient_email_address";

        Properties properties = new Properties();
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");
        properties.put("mail.smtp.host", host);
        properties.put("mail.smtp.port", port);

        Session session = Session.getInstance(properties, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        });

        try {
            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(fromAddress));
            message.setRecipient(Message.RecipientType.TO, new InternetAddress(toAddress));
            message.setSubject("Service Performance Report - " + serviceName);

            /*DataSource dataSource = new ByteArrayDataSource(chartImageBytes, "image/png");

            // Attach the chart as an inline image
            message.setContent(emailBody, "text/html");
            message.setDataHandler(new DataHandler(dataSource));
            message.setFileName("performance_chart.png");
            message.setHeader("Content-ID", "<chart>");  */

            Transport.send(message);

            System.out.println("Email sent successfully for " + serviceName);
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }
}

class ServiceInfo {
    private String name;
    private String endpoint;

    public ServiceInfo(String name, String endpoint) {
        this.name = name;
        this.endpoint = endpoint;
    }

    public String getName() {
        return name;
    }

    public String getEndpoint() {
        return endpoint;
    }
}

class PerformanceData {
    private long minResponseTime;
    private long maxResponseTime;
    private long medianResponseTime;

    public PerformanceData(long minResponseTime, long maxResponseTime, long medianResponseTime) {
        this.minResponseTime = minResponseTime;
        this.maxResponseTime = maxResponseTime;
        this.medianResponseTime = medianResponseTime;
    }

    public long getMinResponseTime() {
        return minResponseTime;
    }

    public long getMaxResponseTime() {
        return maxResponseTime;
    }

    public long getMedianResponseTime() {
        return medianResponseTime;
    }
}
